﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {
	public GameObject bulletPrefab;
	public Transform bulletSpawn;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space)) 
		{
			Fire ();
		}
	}
	// something I found on the internet to make a working bullet.  A little buggy but should work.  
	void Fire()
	{
		var bullet = (GameObject)Instantiate 
			(bulletPrefab,
				bulletSpawn.position,
				bulletSpawn.rotation);
		bullet.GetComponent<Rigidbody2D> ().velocity = bullet.transform.right * 6;
		Destroy (bullet, 2.0f);

	}



}


