﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {
    private Transform tf;
	public float speed;
	public float turnSpeed;
	// Use this for initialization

    void Start () 
	{
		
        tf = GetComponent<Transform>();

	}
	// Update is called once per frame
	void Update () 
	// basic tank controls
	{

			if (Input.GetKey (KeyCode.UpArrow)) 
		{
			tf.Translate (Vector3.right * 0.02f, Space.Self);

			//if (Input.GetKey (KeyCode.UpArrow)) {
			//tf.position = tf.position + (GetComponent<Transform>().up * speed);
		}
			if (Input.GetKey (KeyCode.LeftArrow)) 
		{
			tf.Rotate(0, 0, turnSpeed);
		}
			if (Input.GetKey (KeyCode.RightArrow)) 
		{
			tf.Rotate(0, 0, -turnSpeed);
		}
		
	}




	void OnTriggerEnter2D ( Collider2D other )
	{
		if (other.gameObject.CompareTag ("asteroid")) 
		{
			Destroy (other.gameObject);
			LifeLost ();

		}
	}
	void LifeLost()
	{
		GameManager.instance.lives--;
		if (GameManager.instance.lives == 0) 
		{
			Application.Quit ();
		}
		else
		{
			GameManager.instance.RemoveEnemies ();
			tf.transform.position = new Vector3 (0, 0, 0);
		}

	}
}