﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour 
{
	public Vector3 direction;


	// Use this for initialization
	void Start () 
	{
		direction = new Vector3(1, 0, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
		direction = new Vector3(1, 0, 0);
		transform.Translate (direction * Time.deltaTime * GameManager.instance.enemyShipSpeed);

		direction = GameManager.instance.player.transform.position - transform.position;
		direction.Normalize ();
		float angle = Mathf.Atan2 (direction.y, direction.x) * Mathf.Rad2Deg;

		transform.rotation = Quaternion.Euler (0f, 0f, angle);

		Quaternion targetRotation = Quaternion.Euler (0, 0, angle);
		transform.rotation = Quaternion.RotateTowards (transform.rotation, targetRotation, GameManager.instance.enemyShipRotationSpeed * Time.deltaTime);

		transform.Translate (Time.deltaTime * GameManager.instance.enemyShipSpeed, 0, 0);
	}
	void OnTriggerEnter2D(Collider2D other)
	//destroy bullet and asteroid and self when collieded with
	{
		if (other.gameObject.tag == "bullet") 
		{
			GameManager.instance.activeEnemies.Remove (this.gameObject);
			Destroy (this.gameObject);
			Destroy (other.gameObject);
		}
	}

}

