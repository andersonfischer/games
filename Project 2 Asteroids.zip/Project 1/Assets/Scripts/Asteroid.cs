﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour 
{
	public Vector2 direction;
	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	//Giving the asteroids a transform and speed
	{
		transform.Translate (direction * Time.deltaTime * GameManager.instance.asteroidSpeed);
	}
	void OnTriggerEnter2D(Collider2D other)
	//destroy bullet and asteroid and self when collieded with
	{
		if (other.gameObject.tag == "bullet") 
		{
			GameManager.instance.activeEnemies.Remove (this.gameObject);
			Destroy (this.gameObject);
			Destroy (other.gameObject);
		}
	}

}
